#!/usr/bin/env python
#
# Copyright 2010 SAP AG
#
# Python DB API v2.0
# NewDB client library


__all__ = [
    'dbapi',
    ]
__version__ = '2.5.101'
